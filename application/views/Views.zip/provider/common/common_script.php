

<script src="<?php echo  base_url();?>assets/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?php echo  base_url();?>assets/plugins/bower_components/styleswitcher/jQuery.style.switcher.js"></script>
<!-- Menu Plugin JavaScript -->
<script src="<?php echo  base_url();?>assets/plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>

<script src="<?php echo  base_url();?>assets/plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script src="<?php echo  base_url();?>assets/plugins/bower_components/timepicker/bootstrap-timepicker.min.js"></script>
<script src="<?php echo  base_url();?>assets/plugins/bower_components/clockpicker/dist/jquery-clockpicker.min.js"></script>
<!--slimscroll JavaScript -->
<script src="<?php echo  base_url();?>assets/js/jquery.slimscroll.js"></script>

<script src="<?php echo base_url();?>assets/plugins/bower_components/switchery/dist/switchery.min.js"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo  base_url();?>assets/js/custom.min.js"></script>

<!-- Custom tab JavaScript -->

<script src="<?php echo base_url();?>assets/plugins/bower_components/datatables/jquery.dataTables.min.js"></script>

<script src="<?php echo base_url()?>assets/plugins/bower_components/Chart.js/chartjs.init.js"></script>
<script src="<?php echo base_url()?>assets/plugins/bower_components/Chart.js/Chart.min.js"></script>
        